// Global Game Variables
let player;
let bullets = [];
let asteroids = [];
let score = 0;
let gameRunning = false;
let gameOver = false;
let showIntro = true;
let showLevelSelect = false;
let bgImage, tankImage, planeImage;
let totalShots = 0;
let hits = 0;
let isMouseHeld = false;
let difficulty = null;
let asteroidSpawnRate = 60;
let asteroidSpeedRange = [2, 5];
let gameStartTime = 0;
let gameDuration = 120000; // 2 minutes in milliseconds
let timeLeft = 0;

// Update your levels configuration
let levels = [
  { name: "Easy", spawnRate: 120, speedRange: [1, 3], duration: 180000 }, // 3 minutes
  { name: "Medium", spawnRate: 80, speedRange: [2, 5], duration: 120000 }, // 2 minutes
  { name: "Hard", spawnRate: 40, speedRange: [3, 7], duration: 90000 } // 1.5 minutes
];


// UI System
var currentUI = window.currentUI;
let classicUI, modernUI;

// Airstrike
let airstrikeActive = false;
let airstrikeTriggered = false;
let planeY = 0;
let planeSpeed = 6;

function preload() {
  bgImage = loadImage('background.jpg');
  tankImage = loadImage('tank.png');
  planeImage = loadImage('plane.png'); // Load airstrike plane
}

function setup() {
    let canvasWidth = currentUI === 'modern' ? 400 : windowWidth;
    let canvasHeight = currentUI === 'modern' ? 700 : windowHeight;
  
    let canvas = createCanvas(canvasWidth, canvasHeight);
    canvas.elt.style.position = 'fixed';
    canvas.elt.style.top = '50%';
    canvas.elt.style.left = '50%';
    canvas.elt.style.transform = 'translate(-50%, -50%)';
    canvas.elt.style.zIndex = '0';
    canvas.elt.style.pointerEvents = 'none';
  
    imageMode(CENTER);
  
    player = new PlayerTank(width / 2, height - 50);
    classicUI = new ClassicUI(width, height);
    modernUI = new ModernUI(width, height);
    setupEventListeners();
    timeLeft = gameDuration;
  }
  



  function draw() {
    if (bgImage) {
      imageMode(CORNER);
      let scale = max(width / bgImage.width, height / bgImage.height);
      let w = bgImage.width * scale;
      let h = bgImage.height * scale;
      image(bgImage, 0, 0, w, h);
    } else {
      background(50);
    }
  
    if (showIntro) {
      currentUI === 'classic' ? showIntroScreenClassic() : showIntroScreenModern();
      return;
    }
    
    
    if (showLevelSelect) {
      currentUI === 'classic' ? showLevelSelectionClassic() : showLevelSelectionModern();
      return;
    }
    
    
      if (!gameRunning) {
        showStartScreen();
        return;
      }
    
      if (gameOver) {
        currentUI === 'classic' ? showGameOverScreenClassic() : showGameOverScreenModern();
        return;
      }
      
    
      // Update time left
      timeLeft = max(0, gameDuration - (millis() - gameStartTime));
      
      if (timeLeft <= 0) {
        gameOver = true;
        return;
      }
  
    if (currentUI === 'classic') {
      classicUI.run();
    } else {
      modernUI.run();

    }
  

  // ✅ Run airstrike BEFORE updating objects
  handleAirstrike();

  updateGameObjects();
  displayGameObjects();

  fill(255);
  textSize(20);
  text("Score: " + score, 20, 30);
  
  

  fill(255);
textSize(20);
textAlign(LEFT);
text("Time Left: " + ceil(timeLeft / 1000) + "s", 20, 90);

// Optional: Show difficulty in top-left corner instead of overlapping bottom
if (difficulty) {
  textSize(20);
  text("Difficulty: " + difficulty.charAt(0).toUpperCase() + difficulty.slice(1), 20, 130);
}
}


function updateGameObjects() {
    player.update();
  
    // Spawn new asteroids
    if (frameCount % asteroidSpawnRate === 0) {
      asteroids.push(new Asteroid(
        random(width), 
        -50, 
        random(asteroidSpeedRange[0], asteroidSpeedRange[1])
      ));
    }
  
    // Update bullets and remove off-screen ones
    for (let i = bullets.length - 1; i >= 0; i--) {
      bullets[i].update();
      if (bullets[i].offScreen()) bullets.splice(i, 1);
    }
  
    // Update asteroids and handle bullet collisions
    for (let i = asteroids.length - 1; i >= 0; i--) {
      asteroids[i].update();
      
      // Remove asteroids that go below screen (no game-over)
      if (asteroids[i].y > height + asteroids[i].size) {
        asteroids.splice(i, 1);
        continue;
      }
  
      // Check bullet collisions (scoring system remains)
      for (let j = bullets.length - 1; j >= 0; j--) {
        if (asteroids[i].hits(bullets[j])) {
          asteroids[i].explode();
          asteroids.splice(i, 1);
          bullets.splice(j, 1);
          score += 10;
          hits++;
          break;
        }
      }
    }
  }

  function findClosestAsteroidToPlayer() {
    let minDist = Infinity;
    let closest = null;
    for (let a of asteroids) {
      let d = dist(a.x, a.y, player.x, player.y);
      if (d < minDist) {
        minDist = d;
        closest = a;
      }
    }
    return closest;
  }
  

function displayGameObjects() {
  player.display();
  bullets.forEach(b => b.display());
  let sortedAsteroids = [...asteroids].sort((a, b) => a.y - b.y);
sortedAsteroids.forEach(a => a.display());

// Highlight the closest asteroid to the player
let closest = findClosestAsteroidToPlayer();
if (closest) {
  noFill();
  stroke(255, 0, 0);
  strokeWeight(3);
  ellipse(closest.x, closest.y, closest.size + 15);
  noStroke();
}

}

// --- AIRSTRIKE ---
function triggerAirstrike() {
  if (!airstrikeActive) {
    planeY = height + 80;
    airstrikeActive = true;
    airstrikeTriggered = false; // reset explosion trigger
  }
}

function handleAirstrike() {
  if (airstrikeActive && planeImage) {
    let planeX = width / 2;
    imageMode(CENTER);
    image(planeImage, planeX, planeY, 300, 300);
    planeY -= planeSpeed;

    if (!airstrikeTriggered && planeY < height / 2) {
      airstrikeTriggered = true;

      // 💥 Destroy all asteroids
      for (let asteroid of asteroids) {
        asteroid.explode();
      }
      asteroids = [];
      score += 50;
    }

    if (planeY < -60) {
      airstrikeActive = false;
    }
  }
}

function setupEventListeners() {
  window.keyPressed = () => {
    if (currentUI === 'classic') {
      if (key === 'a' || key === 'A') player.moveLeft();
      if (key === 'd' || key === 'D') player.moveRight();
      if (key === ' ') {
        let speed = classicUI.getSliderValue();
        bullets.push(new Bullet(player.x, player.y - 20, speed));
        totalShots++; // ✅ Track fired shots
      }
      
      if (key === 'e' || key === 'E') {
        triggerAirstrike();
      }
    }
  };

  window.keyReleased = () => {
    if (key === 'a' || key === 'A' || key === 'd' || key === 'D') {
      player.stop();
    }
  };

  window.touchStarted = (e) => {
    if (currentUI === 'modern') {
      e.touches.forEach(t => {
        modernUI.handleTouchStarted({ x: t.clientX, y: t.clientY, id: t.identifier });
      });
    }
    return false;
  };

  window.touchMoved = (e) => {
    if (currentUI === 'modern') {
      e.touches.forEach(t => {
        modernUI.handleTouchMoved({ x: t.clientX, y: t.clientY, id: t.identifier });
      });
    }
    return false;
  };

  window.touchEnded = (e) => {
    if (currentUI === 'modern') {
      Array.from(e.changedTouches).forEach(t => {
        modernUI.handleTouchEnded(t.identifier);
      });
    }
    return false;
  };

  window.mousePressed = () => {
    if (currentUI === 'modern') {
      modernUI.handleTouch(mouseX, mouseY, 'start');
  
      // Fire logic for desktop
      let fireX = modernUI.fireButton.x;
      let fireY = modernUI.fireButton.y;
      let fireRadius = modernUI.fireButton.radius;
  
      if (dist(mouseX, mouseY, fireX, fireY) < fireRadius) {
        if (modernUI.fireCooldown <= 0) {
          bullets.push(new Bullet(player.x, player.y - 20, modernUI.getSliderValue()));
          totalShots++; // ✅ Track desktop shot
          modernUI.fireCooldown = 15;
          modernUI.fireButton.isPressed = true; // optional visual effect
        }
      }
    }
  };
  

  window.mouseDragged = () => {
    if (currentUI === 'modern') modernUI.handleTouch(mouseX, mouseY, 'move');
  };

  window.mouseReleased = () => {
    if (currentUI === 'modern') {
      modernUI.handleTouch(mouseX, mouseY, 'end');
      modernUI.fireButton.isPressed = false; // ✅ reset fire state for desktop
    }
  };
  
  
}
function showIntroScreenModern() {
  background(10, 10, 30);

  // Top title
  textAlign(LEFT, TOP);
  textSize(28);
  fill(0, 255, 255);
  text("ASTEROID DEFENSE", 20, 20);

  // Instructions
  fill(255);
  textSize(16);
  text("🚀 Earth is under asteroid attack.\n🛡️ Use your tank to destroy them.\n🎯 Earn points by hitting targets.", 20, 80);

  // Tap cue at bottom
  let flicker = map(sin(millis() / 300), -1, 1, 100, 255);
  fill(255, 255, 0, flicker);
  textSize(18);
  text("👆 Tap anywhere to continue", width / 2, height - 60);
  textAlign(CENTER);

  if (mouseIsPressed) {
    showIntro = false;
    showLevelSelect = true;
  }
}

function showLevelSelectionModern() {
  background(5, 5, 25);

  // 💬 Heading - now bigger
  textAlign(LEFT, TOP);
  fill(0, 255, 180);
  textSize(32);
  let titleX = 350;
  let titleY = height / 2 - 700;
  text("Choose Difficulty:", titleX, titleY);

  let emojis = ["🚀", "💣", "☠️"];
  let labels = ["Easy", "Medium", "Hard"];
  let infos = [
    `Spawn: ${levels[0].spawnRate}ms | Time: ${levels[0].duration / 1000}s`,
    `Spawn: ${levels[1].spawnRate}ms | Time: ${levels[1].duration / 1000}s`,
    `Spawn: ${levels[2].spawnRate}ms | Time: ${levels[2].duration / 1000}s`
  ];

  let tileHeight = 250;
  let spacing = 10;

  // Centered vertically
  let totalHeight = emojis.length * tileHeight + (emojis.length - 1) * spacing;
  let startY = (height - totalHeight) / 2;

  for (let i = 0; i < emojis.length; i++) {
    let x = width / 2;
    let y = startY + i * (tileHeight + spacing);
    let iconSize = 110;
    let isHover = dist(mouseX, mouseY, x, y) < iconSize / 2;

    // Hover ring
    if (isHover) {
      noFill();
      stroke(0, 255, 255, 180);
      strokeWeight(4);
      ellipse(x, y, iconSize + 30);
    }

    // ✨ Emoji icon
    textAlign(CENTER, CENTER);
    textSize(isHover ? 110 : 100);
    noStroke();
    fill(255);
    text(emojis[i], x, y - 30);

    // 🏷️ Label
    textSize(24);
    text(labels[i], x, y + 40);
    
    // 🕒 Info
    textSize(18);
    fill(200);
    text(infos[i], x, y + 70);

    if (isHover && mouseIsPressed) {
      selectLevel(levels[i]);
      return;
    }
  }

  // 📌 Footer prompt
  let flicker = map(sin(millis() / 250), -1, 1, 100, 255);
  fill(255, 255, 100, flicker);
  textSize(20);
  textAlign(CENTER);
  text("Tap an icon to start", width / 2, height - 50);
}

function showGameOverScreenModern() {
  background(15);

  textAlign(CENTER, CENTER);
  fill(255, 100, 100);
  textSize(48);
  text("GAME OVER", width / 2, height / 4);

  fill(255);
  textSize(28);
  text(`Score: ${score}`, width / 2, height / 2 - 40);
  text(`Difficulty: ${difficulty}`, width / 2, height / 2);
  
  let accuracy = totalShots > 0 ? (hits / totalShots * 100).toFixed(1) : "0.0";
  text(`Accuracy: ${accuracy}%`, width / 2, height / 2 + 40);

  // ✨ Blinking restart prompt
  let flicker = map(sin(millis() / 300), -1, 1, 100, 255);
  fill(255, 255, 0, flicker);
  textSize(24);
  text("👆 Tap to Play Again", width / 2, height - 100);

  // 🎆 Add subtle sparkle particles
  for (let i = 0; i < 20; i++) {
    fill(random(255), random(200, 255), 100, random(100, 180));
    ellipse(random(width), random(height), random(2, 6));
  }

  if (mouseIsPressed) resetGame();
}


function showIntroScreenClassic(){
  background(0);

  // Glowing title
  textAlign(CENTER, CENTER);
  textSize(70);
  for (let i = 0; i < 10; i++) {
    fill(255, 0, 0, 25);
    text("ASTEROID DEFENSE GAME", width / 2 + random(-2, 2), height / 4 + random(-2, 2));
  }

  fill(255);
  textAlign(CENTER, CENTER);
  
  textSize(40); // reduced slightly to avoid overlap
  text("Earth is under attack by asteroids!", width / 2, height / 2 - 80);
  
  textSize(30);
  text("Shoot them down before they strike.", width / 2, height / 2 - 30);
  
  textSize(28);
  text("Score points. Stay alive. Defend Earth.", width / 2, height / 2 + 10);
  
  // Animated flicker on 'Click to continue'
  let flickerAlpha = map(sin(millis() / 300), -1, 1, 100, 255);
  fill(255, 255, 0, flickerAlpha);
  textSize(26);
  text("Click to Continue", width / 2, height - 100);

  // Stars background effect
  for (let i = 0; i < 50; i++) {
    fill(255, random(100, 200));
    ellipse(random(width), random(height), random(1, 3));
  }

  if (mouseIsPressed) {
    showIntro = false;
    showLevelSelect = true;
  }
}


function showLevelSelectionClassic() {
  // Dark starry background
  background(0, 0, 30);

  // ✨ Twinkling stars
  for (let i = 0; i < 100; i++) {
    fill(255, random(80, 160));
    ellipse(random(width), random(height), random(0.5, 2.5));
  }

  // 🟦 Glowing title text
  textAlign(CENTER, CENTER);
  textSize(42);
  fill(0, 200, 255);
  for (let i = 0; i < 5; i++) {
    text("SELECT DIFFICULTY", width / 2 + random(-1, 1), height / 6 + random(-1, 1));
  }

  // 🔲 Button layout setup
  let buttonHeight = 100;
  let buttonWidth = 300;
  let startY = height / 3;

  for (let i = 0; i < levels.length; i++) {
    let level = levels[i];
    let y = startY + i * (buttonHeight + 30);

    // ✋ Hover detection
    let isHover =
      mouseX > width / 2 - buttonWidth / 2 &&
      mouseX < width / 2 + buttonWidth / 2 &&
      mouseY > y &&
      mouseY < y + buttonHeight;

    // 🎨 Button background
    push();
    if (isHover) {
      stroke(0, 255, 255);
      strokeWeight(3);
      fill(30, 30, 50);
    } else {
      noStroke();
      fill(20, 20, 40);
    }
    rect(width / 2 - buttonWidth / 2, y, buttonWidth, buttonHeight, 16);
    pop();

    // 🖋 Text styles
    fill(255);
    textSize(28);
    text(level.name, width / 2, y + 28);

    textSize(14);
    text(`Spawn Rate: ${level.spawnRate} ms`, width / 2, y + 56);
    text(`Duration: ${level.duration / 1000} s`, width / 2, y + 76);

    // 👆 Button click action
    if (isHover && mouseIsPressed) {
      selectLevel(level);
      return;
    }
  }

  // ✨ Decorative hint text
  let flicker = map(sin(millis() / 250), -1, 1, 180, 255);
  fill(255, 255, 100, flicker);
  textSize(18);
  text("Hover & Click a difficulty to begin", width / 2, height - 60);
}


  function selectLevel(level) {
  difficulty = level.name.toLowerCase();
  asteroidSpawnRate = level.spawnRate;
  asteroidSpeedRange = level.speedRange;
  gameDuration = level.duration;
  showLevelSelect = false;
  gameRunning = true;
  gameStartTime = millis(); // Start the timer
  timeLeft = gameDuration;
  
  // Reset game state
  score = 0;
  bullets = [];
  asteroids = [];
  player.x = width / 2;
}

function showGameOverScreenClassic() {
  background(20);

  // Glowing 'Game Over'
  textAlign(CENTER, CENTER);
  for (let i = 0; i < 10; i++) {
    fill(255, 0, 0, 20);
    textSize(60);
    text("GAME OVER", width / 2 + random(-2, 2), height / 3 + random(-2, 2));
  }

  fill(255);
  textSize(24);
  text(`Final Score: ${score}`, width / 2, height / 2 - 20);
  text(`Difficulty: ${difficulty}`, width / 2, height / 2 + 10);
  let accuracy = totalShots > 0 ? (hits / totalShots * 100).toFixed(1) : "0.0";
  text(`Accuracy: ${accuracy}%`, width / 2, height / 2 + 40);

  let pulse = map(sin(millis() / 300), -1, 1, 180, 255);
  fill(255, 255, 0, pulse);
  textSize(26);
  text("Click to Play Again", width / 2, height / 2 + 100);

  // Explosion sparks around text
  for (let i = 0; i < 20; i++) {
    fill(random(200, 255), random(50, 100), 0, random(80, 180));
    ellipse(random(width), random(height), random(2, 6));
  }

  if (mouseIsPressed) resetGame();
}

function resetGame() {
    gameRunning = false;
    gameOver = false;
    score = 0;
    bullets = [];
    asteroids = [];
    player.x = width / 2;
    showLevelSelect = true;
    timeLeft = gameDuration;
  }
  

class GameObject {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.width = 0;
    this.height = 0;
  }
  update() {}
  display() {}
}

class PlayerTank extends GameObject {
  constructor(x, y) {
    super(x, y);
    this.width = 80;
    this.height = 50;
    this.speed = 10;
    this.movingLeft = false;
    this.movingRight = false;
  }

  update() {
    if (this.movingLeft && this.x > this.width / 2) this.x -= this.speed;
    if (this.movingRight && this.x < width - this.width / 2) this.x += this.speed;
  }

  display() {
    if (tankImage) {
      imageMode(CENTER);
      image(tankImage, this.x, this.y, 200, 200);
    } else {
      fill(0, 255, 0);
      rect(this.x - this.width / 2, this.y - this.height / 2, this.width, this.height);
    }
  }

  moveLeft() { this.movingLeft = true; }
  moveRight() { this.movingRight = true; }
  stop() { this.movingLeft = false; this.movingRight = false; }
}

// class Bullet extends GameObject {
//   constructor(x, y, speed) {
//     super(x, y);
//     this.speed = speed;
//     this.diameter = 10;
//   }

//   update() {
//     this.y -= this.speed;
//   }

//   display() {
//     fill(255, 255, 0);
//     noStroke();
//     ellipse(this.x, this.y, this.diameter);
//   }

//   offScreen() {
//     return this.y < 0;
//   }
// }

class Bullet extends GameObject {
  constructor(x, y, speed) {
    super(x, y);
    this.speed = speed;
    this.width = 6;
    this.height = 20;
    this.diameter = 10;
  }

  update() {
    this.y -= this.speed;
  }

  display() {
    push();
    translate(this.x, this.y);

    // 🔥 Glow effect (outer aura)
    noStroke();
    fill(255, 255, 100, 80);
    ellipse(0, 0, this.width + 12, this.height + 25);

    // 🌟 Core metallic bullet body with gradient-like colors
    for (let i = 0; i < 5; i++) {
      fill(180 + i * 15, 180 + i * 10, 100); // metallic color gradient
      rectMode(CENTER);
      rect(0, 0 - i * 1.5, this.width - i, this.height - i * 3, 4);
    }

    // ✨ Tip flash (like muzzle glow)
    fill(255, 240, 150, 180);
    ellipse(0, -this.height / 2, this.width, this.width);

    pop();
  }

  offScreen() {
    return this.y < 0;
  }
}

class Asteroid extends GameObject {
    constructor(x, y, speed) {
        super(x, y);
        this.size = random(40, 80);
        this.width = this.size;
        this.height = this.size;
        this.speed = speed; // Use passed speed
        this.isBurning = false;
      }

  update() {
    this.y += this.speed;
    if (this.y > height * 0.6) this.isBurning = true;
  }

  display() {
    push();
    translate(this.x, this.y);
  
    // Shadow glow for realism
    noStroke();
    fill(80, 80, 80, 50);
    ellipse(5, 5, this.size * 1.2);
  
    // Base asteroid color with gradient
    for (let r = this.size; r > 0; r -= 5) {
      fill(100 + r, 100 + r * 0.5, 100 + r * 0.3); 
      ellipse(0, 0, r);
    }
  
    // Random craters
    for (let i = 0; i < 5; i++) {
      let angle = random(TWO_PI);
      let radius = this.size * 0.4 * random(0.3, 1);
      let cx = cos(angle) * radius;
      let cy = sin(angle) * radius;
      fill(50, 50, 50, 180);
      ellipse(cx, cy, random(3, 8));
    }
  
    // Fire if burning
    if (this.isBurning) this.drawFireEffect();
  
    pop();
  }

  hits(target) {
    let distance = dist(this.x, this.y, target.x, target.y);
    return distance < (this.size / 2 + target.width / 2);
  }

  // explode() {
  //   for (let i = 0; i < 10; i++) {
  //     fill(random(255), random(255), random(255));
  //     ellipse(this.x + random(-20, 20), this.y + random(-20, 20), random(5, 15));
  //   }
  // }

  explode() {
    push();
    for (let i = 0; i < 30; i++) {
      let angle = random(TWO_PI);
      let radius = random(5, 30);
      let xOffset = cos(angle) * radius;
      let yOffset = sin(angle) * radius;
  
      // Glowing spark particles
      noStroke();
      fill(255, random(100, 255), 0, 180);
      ellipse(this.x + xOffset, this.y + yOffset, random(4, 8));
    }
  
    // Shockwave ring
    noFill();
    stroke(255, 200, 100, 180);
    strokeWeight(2);
    ellipse(this.x, this.y, this.size * 1.5);
  
    pop();
  }
  

  drawFireEffect() {
    noStroke();
    let r1 = this.size * random(1.3, 1.6);
    let r2 = this.size * random(1.0, 1.3);
  
    fill(255, 140, 0, 180);
    ellipse(0, 0, r1);
    fill(255, 200, 50, 200);
    ellipse(0, 0, r2);
  }
}

window.resetUI = function () {
  if (currentUI === 'classic') {
    player.stop();
  } else {
    modernUI.reset();
  }
};
