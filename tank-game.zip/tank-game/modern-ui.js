// Updated ModernUI with styled joystick, instructions, and airstrike
class ModernUI {
    constructor(canvasWidth, canvasHeight) {
      this.canvasWidth = canvasWidth;
      this.canvasHeight = canvasHeight;
      this.lastScore = score;
this.scoreAnimation = 0;
this.comboMultiplier = 1;
this.comboTimer = 0;

  
      this.joystick = {
        baseX: 150,
        baseY: canvasHeight - 100,
        handleX: 90,
        handleY: canvasHeight - 180,
        radius: 70,         // bigger outer ring
        handleRadius: 35,   // bigger inner handle
        isActive: false,
        touchId: null
      };
  
      this.fireButton = {
        x: canvasWidth - 200,
        y: canvasHeight - 100,
        radius: 80, // ⬅️ Increased from 40 to 60
        isPressed: false,
        touchId: null
      };
      
  
      this.fireCooldown = 0;
      this.activeTouches = {};
  
      this.sliderX = 120;
      this.sliderY = canvasHeight - 60;
      this.sliderWidth = 200;
      this.sliderHeight = 20;
      this.sliderPos = this.sliderX + this.sliderWidth / 2;
      this.draggingSlider = false;
    }
  
    handleTouch(x, y, type) {
      const fireDist = dist(x, y, this.fireButton.x, this.fireButton.y);
      const joyDist = dist(x, y, this.joystick.baseX, this.joystick.baseY);
      let id = 'mouse';
      if (fireDist < this.fireButton.radius) id = 'mouse-fire';
      if (joyDist < this.joystick.radius) id = 'mouse-joy';
      const touch = { x, y, id };
  
      if (type === 'start') this.handleTouchStarted(touch);
      else if (type === 'move') this.handleTouchMoved(touch);
      else if (type === 'end') this.handleTouchEnded(id);
    }
  
    handleTouchStarted(touch) {
        
            const { x, y, id } = touch;
            this.activeTouches[id] = { x, y };
          
            // 🔁 Reset
            if (dist(x, y, 70, this.canvasHeight - 100) < 50) {
              this.activeTouches['resetBtn'] = true;
              resetGame();
            }
          
            // ✈️ Airstrike
            if (dist(x, y, this.canvasWidth - 70, this.canvasHeight - 100) < 50) {
              this.activeTouches['airBtn'] = true;
              this.triggerAirStrike();
            }
      
      if (dist(x, y, this.fireButton.x, this.fireButton.y) < this.fireButton.radius && !this.fireButton.touchId) {
        this.fireButton.isPressed = true;
        this.fireButton.touchId = id;
        return;
      }
  
      if (dist(x, y, this.joystick.baseX, this.joystick.baseY) < this.joystick.radius && !this.joystick.touchId) {
        this.joystick.isActive = true;
        this.joystick.touchId = id;
        this.updateJoystickPosition(x, y);
      }
  
      if (
        x > this.sliderPos &&
        x < this.sliderPos + 10 &&
        y > this.sliderY &&
        y < this.sliderY + this.sliderHeight
      ) {
        this.draggingSlider = true;
      }
  
      if (x > 10 && x < 110 && y > this.canvasHeight - 60 && y < this.canvasHeight - 10) {
        resetGame();
      }
  
      if (x > this.canvasWidth - 110 && x < this.canvasWidth - 10 && y > this.canvasHeight - 60 && y < this.canvasHeight - 10) {
        this.triggerAirStrike();
      }
    }
  
    handleTouchMoved(touch) {
      const { x, y, id } = touch;
      this.activeTouches[id] = { x, y };
  
      if (this.joystick.touchId === id) {
        this.updateJoystickPosition(x, y);
      }
  
      if (this.draggingSlider) {
        this.sliderPos = constrain(x, this.sliderX, this.sliderX + this.sliderWidth - 10);
      }
    }
  
    handleTouchEnded(id) {
      delete this.activeTouches[id];
  
      if (this.fireButton.touchId === id) {
        this.fireButton.isPressed = false;
        this.fireButton.touchId = null;
      }
  
      if (this.joystick.touchId === id) {
        this.joystick.isActive = false;
        this.joystick.touchId = null;
        this.joystick.handleX = this.joystick.baseX;
        this.joystick.handleY = this.joystick.baseY;
        player.stop();
      }

  delete this.activeTouches['resetBtn'];
  delete this.activeTouches['airBtn'];

      this.draggingSlider = false;
    }
  
    run() {
      // ✅ Draw modern mode instruction
      fill(255);
      textSize(20);
      textAlign(CENTER, TOP);
      text("Modern Mode: Use Touch Controls (Joystick / Fire)", width / 2, 10);
  
      this.drawJoystick();
      this.drawFireButton();
      this.drawSpeedControls();

      this.drawControls();
      this.updateMovement();
      this.updateFireButton();
      this.drawScore();
      if (score > this.lastScore) {
        this.scoreAnimation = 1;
        this.comboTimer = 180; // 3 seconds window
        this.comboMultiplier += 1;
        this.lastScore = score;
      } else if (this.comboTimer > 0) {
        this.comboTimer--;
      } else {
        this.comboMultiplier = 1;
      }
      
    }
  
    drawJoystick() {
        push();
      
        // Draw outer metallic ring with gradient illusion
        let gradientSteps = 10;
        for (let i = gradientSteps; i > 0; i--) {
          let stepColor = lerpColor(color(60, 60, 80), color(30), i / gradientSteps);
          fill(stepColor);
          ellipse(this.joystick.baseX, this.joystick.baseY, this.joystick.radius * 2 * (i / gradientSteps));
        }
      
        // Inner glowing ring for highlight
        fill(0, 120, 255, 100);
        ellipse(this.joystick.baseX, this.joystick.baseY, this.joystick.radius * 1.5);
      
        // Joystick handle with shadow for depth
        fill(0, 150, 255);
        stroke(255);
        strokeWeight(2);
        ellipse(this.joystick.handleX, this.joystick.handleY, this.joystick.handleRadius * 2);
      
        pop();
      }
      
  
    drawFireButton() {
      fill(this.fireButton.isPressed ? 255 : 200, 50, 50, this.fireButton.isPressed ? 220 : 180);
      noStroke();
      ellipse(this.fireButton.x, this.fireButton.y, this.fireButton.radius * 2);
      fill(255);
      textSize(16);
      textAlign(CENTER, CENTER);
      text("FIRE", this.fireButton.x, this.fireButton.y);
    }
  
    drawSpeedControls() {
        const margin = 20;
        const boxWidth = 220;
        const boxHeight = 120;
        const scoreboardY = margin;
        const speedY = scoreboardY + boxHeight + 20; // right below scoreboard
        const x = this.canvasWidth - boxWidth + 20;
      
        // Background box
        fill(30, 30, 30, 200);
        stroke(100);
        strokeWeight(1);
        rect(x - 10, speedY - 10, 180, 50, 8);
        noStroke();
      
        // Minus Button
        fill(200);
        rect(x, speedY, 30, 30, 5);
        fill(0);
        textSize(20);
        textAlign(CENTER, CENTER);
        text("-", x + 15, speedY + 15);
      
        // Plus Button
        fill(200);
        rect(x + 100, speedY, 30, 30, 5);
        fill(0);
        text("+", x + 115, speedY + 15);
      
        // Display Value
        fill(255);
        textSize(14);
        textAlign(CENTER, CENTER);
        text("Speed: " + this.getSliderValue().toFixed(1), x + 65, speedY + 15);
      
        // Tap detection
        if (mouseIsPressed && currentUI === 'modern') {
          if (mouseX > x && mouseX < x + 30 && mouseY > speedY && mouseY < speedY + 30) {
            this.sliderPos = max(this.sliderX, this.sliderPos - 1);
          } else if (mouseX > x + 100 && mouseX < x + 130 && mouseY > speedY && mouseY < speedY + 30) {
            this.sliderPos = min(this.sliderX + this.sliderWidth - 10, this.sliderPos + 1);
          }
        }
      }
      
      drawControls() {
        this.drawCircleButton(100, this.canvasHeight - 230, 50, "↻", resetGame, this.isButtonPressed('reset'));
        this.drawCircleButton(this.canvasWidth - 100, this.canvasHeight - 200, 50, "✈️", () => this.triggerAirStrike(), this.isButtonPressed('airstrike'));
      }
      
      drawCircleButton(x, y, radius, label, onClick, isPressed) {
        push();
        translate(x, y);
      
        // Shadow/glow
        if (isPressed) {
          fill(180);
          scale(0.95);
        } else {
          fill(230);
        }
        noStroke();
        ellipse(0, 0, radius * 2);
      
        // Label (Emoji or Icon)
        fill(30);
        textAlign(CENTER, CENTER);
        textSize(24);
        text(label, 0, 2);
      
        // Click detection (mouse for dev)
        if (mouseIsPressed &&
            dist(mouseX, mouseY, x, y) < radius &&
            currentUI === 'modern') {
          onClick();
        }
      
        pop();
      }
      isButtonPressed(type) {
        if (type === 'reset') {
          return this.activeTouches['resetBtn'];
        } else if (type === 'airstrike') {
          return this.activeTouches['airBtn'];
        }
        return false;
      }
            
    drawButton(x, y, w, h, label, onClick) {
      fill(200);
      rect(x, y, w, h, 5);
      fill(0);
      textSize(16);
      textAlign(CENTER, CENTER);
      text(label, x + w / 2, y + h / 2);
  
      if (mouseIsPressed && mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h) {
        onClick();
      }
    }
  
    updateJoystickPosition(x, y) {
      const dx = x - this.joystick.baseX;
      const dy = y - this.joystick.baseY;
      const distance = dist(x, y, this.joystick.baseX, this.joystick.baseY);
      if (distance <= this.joystick.radius) {
        this.joystick.handleX = x;
        this.joystick.handleY = y;
      } else {
        const angle = atan2(dy, dx);
        this.joystick.handleX = this.joystick.baseX + cos(angle) * this.joystick.radius;
        this.joystick.handleY = this.joystick.baseY + sin(angle) * this.joystick.radius;
      }
    }
  
    updateMovement() {
      if (!this.joystick.isActive) return;
      const dx = this.joystick.handleX - this.joystick.baseX;
      const deadZone = 10;
      if (dx < -deadZone) player.moveLeft();
      else if (dx > deadZone) player.moveRight();
      else player.stop();
  
      if (this.fireButton.isPressed && this.fireCooldown <= 0) {
        bullets.push(new Bullet(player.x, player.y - 20, this.getSliderValue()));
        totalShots++; // ✅ Track fired shots
        this.fireCooldown = 15;
      }
      
  
      if (this.fireCooldown > 0) {
        this.fireCooldown--;
      }
    }

    updateFireButton() {
        if (this.fireButton.isPressed && this.fireCooldown <= 0) {
          bullets.push(new Bullet(player.x, player.y - 20, this.getSliderValue()));
          totalShots++;
          this.fireCooldown = 15;
        }
      
        if (this.fireCooldown > 0) {
          this.fireCooldown--;
        }
      }
      
  
    triggerAirStrike() {
      console.log("Air strike triggered!");
      triggerAirstrike(); // animation only
    }
  
    getSliderValue() {
      return map(this.sliderPos, this.sliderX, this.sliderX + this.sliderWidth - 10, 1, 10);
    }
  
    reset() {
      this.joystick.isActive = false;
      this.joystick.handleX = this.joystick.baseX;
      this.joystick.handleY = this.joystick.baseY;
      this.fireButton.isPressed = false;
      this.fireCooldown = 0;
      this.activeTouches = {};
      this.draggingSlider = false;
      player.stop();
    }

    drawScore() {
        push();
      
        let margin = 20;
        let boxWidth = 220;
        let boxHeight = 120;
        let panelX = this.canvasWidth - boxWidth - margin;
        let panelY = margin;
      
        // Background panel
        fill(20, 30, 60, 200);
        stroke(0, 150, 255);
        strokeWeight(2);
        rect(panelX, panelY, boxWidth, boxHeight, 12);
        noStroke();
      
        // Header
        fill(255);
        textSize(18);
        textAlign(CENTER, TOP);
        text("SCOREBOARD", panelX + boxWidth / 2, panelY + 8);
      
        // Score
        textSize(16);
        textAlign(LEFT, TOP);
        text("Score: " + score, panelX + 15, panelY + 35);
      
        // Kill count (equal to score / 10 if 10 pts per asteroid)
        let kills = floor(score / 10);
        text("Kills: " + kills, panelX + 15, panelY + 55);
      
        // Accuracy
        let accuracy = totalShots > 0 ? (hits / totalShots * 100).toFixed(1) : "0.0";
        text("Accuracy: " + accuracy + "%", panelX + 15, panelY + 75);
      
        // Progress bar
        let progress = map(score % 100, 0, 100, 0, boxWidth - 30);
        fill(0, 100, 255);
        rect(panelX + 15, panelY + 100, progress, 10, 5);
        noFill();
        stroke(255);
        rect(panelX + 15, panelY + 100, boxWidth - 30, 10, 5);
      
        pop();
      }
      
      
      
  }
  