class ClassicUI {
    constructor(canvasWidth, canvasHeight) {
      this.sliderX = 120;
      this.sliderY = canvasHeight - 60;
      this.sliderWidth = 200;
      this.sliderHeight = 20;
      this.sliderPos = this.sliderX + this.sliderWidth / 2;
      this.draggingSlider = false;
    }
  
    run() {
        this.drawButton(10, height - 60, 100, 50, "Reset", () => resetGame());
        this.drawButton(width - 110, height - 60, 100, 50, "Air Strike", () => triggerAirstrike());
        this.drawSlider();
        this.drawScore();

      
        fill(255); // white color
        textSize(20);
        textAlign(CENTER, TOP);
        text("Classic Mode: Use Keyboard (A/D/Space)", width / 2, 10);
      }
      
  
    drawButton(x, y, w, h, label, onClick) {
      fill(200);
      rect(x, y, w, h, 5);
      fill(0);
      textSize(16);
      textAlign(CENTER, CENTER);
      text(label, x + w / 2, y + h / 2);
  
      if (
        mouseIsPressed &&
        mouseX > x && mouseX < x + w &&
        mouseY > y && mouseY < y + h
      ) {
        onClick();
      }
    }
  
    drawSlider() {
      fill(150);
      rect(this.sliderX, this.sliderY, this.sliderWidth, this.sliderHeight, 10);
      fill(100);
      rect(this.sliderPos, this.sliderY, 10, this.sliderHeight);
  
      if (this.draggingSlider) {
        this.sliderPos = constrain(mouseX, this.sliderX, this.sliderX + this.sliderWidth - 10);
      }
  
      if (
        mouseIsPressed &&
        mouseX > this.sliderPos &&
        mouseX < this.sliderPos + 10 &&
        mouseY > this.sliderY &&
        mouseY < this.sliderY + this.sliderHeight
      ) {
        this.draggingSlider = true;
      } else if (!mouseIsPressed) {
        this.draggingSlider = false;
      }
  
      let sliderValue = this.getSliderValue();
      fill(255);
      textSize(14);
      textAlign(LEFT, CENTER);
      text("Bullet Speed: " + sliderValue.toFixed(1), this.sliderX, this.sliderY - 20);
    }
  
    getSliderValue() {
      return map(this.sliderPos, this.sliderX, this.sliderX + this.sliderWidth - 10, 1, 10);
    }

    drawScore() {
        push();
        let boxWidth = 160;
        let boxHeight = 40;
        let margin = 20;
      
        fill(0); // black background
        rect(width - boxWidth - margin, margin, boxWidth, boxHeight, 5);
      
        fill(0, 255, 0); // retro green text
        textSize(24);
        textAlign(LEFT, CENTER);
        text("Score: " + score, width - boxWidth + 10 - margin, margin + boxHeight / 2);
        pop();
      }

      
      
  }