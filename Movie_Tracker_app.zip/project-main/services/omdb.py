# services/omdb.py
import httpx
import os

OMDB_API_KEY = os.getenv("OMDB_API_KEY")

async def fetch_omdb_data(title: str):
    url = f"http://www.omdbapi.com/?apikey={OMDB_API_KEY}&t={title}"
    async with httpx.AsyncClient() as client:
        response = await client.get(url)
        if response.status_code == 200:
            data = response.json()
            if data.get("Response") == "True":
                return {
                    "title": data.get("Title"),
                    "year": data.get("Year"),
                    "director": data.get("Director"),
                    "poster_url": data.get("Poster")
                }
        return None
