# Movie Tracker 🎬

[![FastAPI](https://img.shields.io/badge/FastAPI-005571?style=for-the-badge&logo=fastapi)](https://fastapi.tiangolo.com/)
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://www.python.org/)


## 📌 Project Description

Movie Tracker is a FastAPI-based web application that allows users to:
- Maintain personal movie collections
- Track watched status (watched/unwatched)
- Search and filter their library
- Access data via REST API
- Manage account with secure authentication
- rate movies, and maintain a watchlist.
- **OMDb API Integration**: Fetch detailed movie information from OMDb (e.g., year, director, poster).

**Theme**: Personal media organization with clean, intuitive interface.

## 🌟 Features

### User Authentication
- Secure registration/login system
- Password hashing with bcrypt
- JWT token-based sessions
- Account management

### Movie Management
- Add new movies with details (title, genre, status)
- Edit existing movie entries
- Mark movies as watched/unwatched
- Delete movies from collection
- View all movies in paginated list

### OMDb API Integration (Key Feature)
- **Fetch Movie Details**: Use the OMDb API to fetch additional movie details like **year**, **director**, and **poster** by clicking the **"Fetch from OMDb"** button next to any movie.
- **Automatic Updates**: The app fetches dynamic data like year, director, and poster image directly from OMDb, saving users time and enhancing the data quality.

### Search & Filter
- Search by movie title or genre
- Filter by watched status
- Combined search with multiple criteria

### Technical Features
- FastAPI backend with async support
- PostgreSQL/SQLite database options
- Dockerized development environment
- Responsive Jinja2 templates
- REST API endpoints

## New API Endpoints

### 1. **Rate Movie API**

The **Rate Movie API** allows users to set or update the rating for a movie. Ratings can be between 1 and 5.

#### Endpoint: `PUT /api/movies/{movie_id}/rate`

* **Description**: 
    * This endpoint allows the user to update the rating of a specific movie.
    * It accepts a rating value between 1 and 5.
* **Request Body**: 
    * `rating` (integer): The new rating for the movie (must be between 1 and 5).
  
#### Example Request (using `curl`):

```bash
curl -X 'PUT' \
  'http://localhost:8002/api/movies/1/rate' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "rating": 4
}'
```

### 2. **Watchlist API**

The **Watchlist API** allows users to add or remove movies from their watchlist.

#### Endpoint 1: `POST /api/movies/{movie_id}/watchlist` (Add Movie to Watchlist)

* **Description**: 
    * This endpoint allows the user to add a movie to their watchlist.
    * It requires the movie ID and adds that movie to the watchlist.
* **Request Body**: None.

#### Example Request (using `curl`):

```bash
curl -X 'POST' \
  'http://localhost:8002/api/movies/1/watchlist' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d ''
```
## 🛠️ Setup & Installation

### Prerequisites
- Docker and Docker Compose
- Python 3.9+

### 1. Clone the Repository
```bash
git clone git@sc-gitlab.ufv.ca:202501comp351on2/ab96/project.git
cd project
```
### 2. Install Dependencies
```bash
pip install -r requirements.txt
```
### 3. Set Up `.env` File

To securely store your environment variables, including the OMDb API key, you need to create a `.env` file in the root of your project directory.

#### Steps to set up the `.env` file:
1. **Create a new file named `.env` in the project root directory.**
2. **Add the following line to your `.env` file:**
```env
OMDB_API_KEY=your_omdb_api_key_here
```

**Note**: Replace `your_omdb_api_key_here` with your actual OMDb API key. You can get your API key by signing up at [OMDb API](http://www.omdbapi.com/apikey.aspx).

### 4. Run the Application Locally
```bash
uvicorn app.main:app --host 127.0.0.1 --port 8002
```
### 5. Run the Application with Docker
```sh
docker-compose up --build -d
```

## API Documentation

### Interactive Documentation
Access these auto-generated docs when the server is running:

| URL Path          | Description                          |
|-------------------|--------------------------------------|
| `/docs`           | Swagger UI (interactive testing)     |
| `/redoc`          | Alternative documentation style      |

### Key Endpoints
| Endpoint              | Method | Description                     |
|-----------------------|--------|---------------------------------|
| `/api/movies/`        | GET    | List all movies (paginated)     |
| `/api/movies/`        | POST   | Add new movie                   |
| `/api/movies/{id}`    | GET    | Get specific movie              |
| `/api/movies/{id}`    | PUT    | Update movie                    |
| `/api/search`         | GET    | Search movies by title/genre    |

### Example Usage
**Get all movies:**
```bash
curl -X GET 'http://localhost:8002/movies/' \
  -H 'Authorization: Bearer YOUR_JWT_TOKEN'
```

## 🖼️ Screenshots

### Login Page
![Login Interface](/static/screenshots/login_page.png)

### Registration page 
![Registration Interface](/static/screenshots/register_page.png)

### Home Page
![Home Interface](/static/screenshots/home_page.png)

### Edit movie page 
![Editing movie Interface](/static/screenshots/edit_movie_page.png)

### Search movie page 
![Searching movie Interface](/static/screenshots/search_movies_page.png)

### OMDb API Integration 
![OMDb API Integration ](/static/screenshots/OMDb_API_Integration.png)

### Rating API Endpoint Integration 
![Rating API Endpoint Integration ](/static/screenshots/rating_API_endpoint.png)

### Watchlist API Endpoint Integration 
![Watchlist API Endpoint Integration ](/static/screenshots/watchlist_API_endpoint.png)



