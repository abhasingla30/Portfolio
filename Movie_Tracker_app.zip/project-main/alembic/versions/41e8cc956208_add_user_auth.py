"""add_user_auth

Revision ID: 41e8cc956208
Revises: 4d2408b3b029
Create Date: 2025-03-30 06:45:02.584903

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '41e8cc956208'
down_revision: Union[str, None] = '4d2408b3b029'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    # Instead of creating the table, just add any missing columns
    op.add_column('users', sa.Column('email', sa.String(), nullable=True))
    op.add_column('users', sa.Column('hashed_password', sa.String(), nullable=True))
    op.add_column('users', sa.Column('is_active', sa.Boolean(), nullable=True))
    op.add_column('users', sa.Column('role', sa.String(), nullable=True))

def downgrade():
    op.drop_column('users', 'email')
    op.drop_column('users', 'hashed_password')
    op.drop_column('users', 'is_active')
    op.drop_column('users', 'role')
    # ### end Alembic commands ###
