"""fix_relationships

Revision ID: 8f7997f19636
Revises: 41e8cc956208
Create Date: 2023-07-20 12:34:56.789012

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.engine import reflection

# Revision identifiers, used by Alembic.
revision = '8f7997f19636'
down_revision = '41e8cc956208'
branch_labels = None
depends_on = None


def upgrade():
    # Create inspector to examine table structure
    conn = op.get_bind()
    inspector = reflection.Inspector.from_engine(conn)
    columns = [col['name'] for col in inspector.get_columns('movies')]
    
    with op.batch_alter_table('movies') as batch_op:
        if 'user_id' in columns:
            batch_op.drop_column('user_id')
        
        batch_op.add_column(sa.Column('owner_id', sa.Integer(), nullable=True))
        batch_op.create_foreign_key(
            'fk_movies_owner_id_users',
            'users', ['owner_id'], ['id']
        )

    with op.batch_alter_table('users') as batch_op:
        batch_op.alter_column('username', type_=sa.String())
        batch_op.create_unique_constraint('uq_users_username', ['username'])


def downgrade():
    with op.batch_alter_table('movies') as batch_op:
        batch_op.drop_constraint('fk_movies_owner_id_users', type_='foreignkey')
        batch_op.drop_column('owner_id')

    with op.batch_alter_table('users') as batch_op:
        batch_op.drop_constraint('uq_users_username', type_='unique')
        batch_op.alter_column('username', type_=sa.TEXT())