from pydantic import BaseModel, EmailStr, ConfigDict
from typing import Optional

class MovieBase(BaseModel):
    title: str
    genre: str
    watched: bool = False
    rating: Optional[int] = None

class MovieCreate(MovieBase):
    pass

class Movie(MovieBase):
    id: int
    owner_id: int  # Add this to match your relationship

    model_config = ConfigDict(from_attributes=True)  # Replaces orm_mode for Pydantic v2

class UserBase(BaseModel):
    email: EmailStr
    username: str  # Added to match your model

class UserCreate(UserBase):
    password: str
    role: Optional[str] = "user"  # Made explicitly optional with default

class User(UserBase):
    id: int
    is_active: bool
    role: Optional[str] = None  # Made optional to match your model
    # Don't include hashed_password in response!

    model_config = ConfigDict(from_attributes=True)  # Pydantic v2 style

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: str | None = None
    username: str | None = None  # Added if you want to use username for auth

class MovieRating(BaseModel):
    rating: int