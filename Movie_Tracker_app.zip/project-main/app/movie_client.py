import requests
import json

BASE_URL = "http://localhost:8002"

def login(email, password):
    response = requests.post(
        f"{BASE_URL}/login",
        data={"username": email, "password": password},
        allow_redirects=False
    )
    if response.status_code == 302:  # Redirect means success
        return response.cookies.get("access_token")
    raise Exception("Login failed")

def get_movies(token):
    response = requests.get(
        f"{BASE_URL}/api/movies/",
        cookies={"access_token": token}
    )
    return response.json()

def rate_movie(token, movie_id, rating):
    response = requests.put(
        f"{BASE_URL}/api/movies/{movie_id}/rate",
        json={"rating": rating},
        cookies={"access_token": token}
    )
    return response.json()

def toggle_watchlist(token, movie_id, add=True):
    url = f"{BASE_URL}/api/movies/{movie_id}/watchlist"
    if add:
        response = requests.post(url, cookies={"access_token": token})
    else:
        response = requests.delete(url, cookies={"access_token": token})
    return response.json()

def main():
    print("Movie API Client")
    email = input("Email: ")
    password = input("Password: ")
    
    try:
        token = login(email, password)
        print("Login successful!")
        
        while True:
            print("\nOptions:")
            print("1. List movies")
            print("2. Rate a movie")
            print("3. Toggle watchlist")
            print("4. Exit")
            
            choice = input("Choose an option: ")
            
            if choice == "1":
                movies = get_movies(token)
                print("\nMovies:")
                for movie in movies:
                    print(f"{movie['id']}: {movie['title']} (Rating: {movie.get('rating', 'N/A')}, Watchlist: {'Yes' if movie.get('in_watchlist') else 'No'})")
            
            elif choice == "2":
                movie_id = input("Enter movie ID to rate: ")
                rating = input("Enter rating (1-5): ")
                result = rate_movie(token, movie_id, int(rating))
                print(f"Rating updated: {result}")
            
            elif choice == "3":
                movie_id = input("Enter movie ID: ")
                action = input("Add to watchlist? (y/n): ").lower() == 'y'
                result = toggle_watchlist(token, movie_id, action)
                print(f"Watchlist updated: {result}")
            
            elif choice == "4":
                break
            
            else:
                print("Invalid choice")
    
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()