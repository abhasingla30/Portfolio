from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from .database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    username = Column(String, unique=True)
    hashed_password = Column(String)
    is_active = Column(Boolean, default=True)
    role = Column(String, nullable=True)  # Make nullable if not required
    
    movies = relationship("Movie", back_populates="owner")

class Movie(Base):
    __tablename__ = "movies"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String)
    genre = Column(String)
    watched = Column(Boolean, default=False)
    rating = Column(Integer, nullable=True)  # Add this line
    owner_id = Column(Integer, ForeignKey("users.id"))
    in_watchlist = Column(Boolean, default=False)

    # OMDb fields
    year = Column(String, nullable=True)
    director = Column(String, nullable=True)
    poster_url = Column(String, nullable=True)
    owner = relationship("User", back_populates="movies")