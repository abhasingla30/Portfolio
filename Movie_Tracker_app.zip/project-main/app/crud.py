# app/crud.py

from sqlalchemy.orm import Session  # Add this import at the top
from . import models, schemas
from . import auth
from typing import Union, Optional, List

def get_movies(db: Session, owner_id: int, skip: int = 0, limit: int = 100) -> List[models.Movie]:
    """Get movies for a specific owner with pagination"""
    return db.query(models.Movie)\
             .filter(models.Movie.owner_id == owner_id)\
             .order_by(models.Movie.id)\
             .offset(skip)\
             .limit(limit)\
             .all()

def get_movie_by_id(db: Session, movie_id: int, owner_id: int) -> Optional[models.Movie]:
    """Get a single movie by ID if it belongs to the owner"""
    return db.query(models.Movie)\
             .filter(models.Movie.id == movie_id, models.Movie.owner_id == owner_id)\
             .first()

def create_movie(db: Session, movie: Union[schemas.MovieCreate, dict], owner_id: int) -> models.Movie:
    """Create a new movie for the specified owner"""
    if isinstance(movie, dict):
        movie_data = movie
    else:
        movie_data = movie.model_dump()
    
    db_movie = models.Movie(**movie_data, owner_id=owner_id)
    db.add(db_movie)
    db.commit()
    db.refresh(db_movie)
    return db_movie

def update_movie(
    db: Session, 
    movie_id: int, 
    movie_update: schemas.MovieBase, 
    owner_id: int
) -> Optional[models.Movie]:
    """Update a movie if it belongs to the owner"""
    db_movie = db.query(models.Movie)\
                 .filter(models.Movie.id == movie_id, models.Movie.owner_id == owner_id)\
                 .first()
    if db_movie:
        update_data = movie_update.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_movie, key, value)
        db.commit()
        db.refresh(db_movie)
    return db_movie

def delete_movie(db: Session, movie_id: int, owner_id: int) -> dict:
    """Delete a movie if it belongs to the owner"""
    db_movie = db.query(models.Movie)\
                 .filter(models.Movie.id == movie_id, models.Movie.owner_id == owner_id)\
                 .first()
    if db_movie:
        db.delete(db_movie)
        db.commit()
        return {"message": "Movie deleted successfully"}
    return {"message": "Movie not found or not owned by user"}

def search_movies(
    db: Session, 
    owner_id: int, 
    title: Optional[str] = None, 
    genre: Optional[str] = None, 
    watched: Optional[bool] = None
) -> List[models.Movie]:
    """Search movies with filters, scoped to owner"""
    query = db.query(models.Movie).filter(models.Movie.owner_id == owner_id)
    if title:
        query = query.filter(models.Movie.title.ilike(f"%{title}%"))
    if genre:
        query = query.filter(models.Movie.genre.ilike(f"%{genre}%"))
    if watched is not None:
        query = query.filter(models.Movie.watched == watched)
    return query.order_by(models.Movie.id).all()

def get_user_by_email(db: Session, email: str) -> Optional[models.User]:
    """Get user by email"""
    return db.query(models.User).filter(models.User.email == email).first()

def create_user(db: Session, user: schemas.UserCreate) -> models.User:
    """Create a new user"""
    hashed_password = auth.get_password_hash(user.password)
    db_user = models.User(
        email=user.email,
        username=user.username,
        hashed_password=hashed_password,
        is_active=True,
        role=user.role
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def rate_movie(db: Session, movie_id: int, rating: int, owner_id: int) -> Optional[models.Movie]:
    """Rate a movie if it belongs to the owner"""
    db_movie = db.query(models.Movie)\
                 .filter(models.Movie.id == movie_id, models.Movie.owner_id == owner_id)\
                 .first()
    
    if db_movie:
        if rating < 1 or rating > 5:
            raise ValueError("Rating must be between 1 and 5")
        db_movie.rating = rating
        db.commit()
        db.refresh(db_movie)
        return db_movie
    return None


