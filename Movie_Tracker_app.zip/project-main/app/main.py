import os
from dotenv import load_dotenv
from datetime import datetime, timedelta
from typing import Optional
import httpx
from fastapi import HTTPException , status
from pydantic import BaseModel


from fastapi import FastAPI, Depends, Request, Form, HTTPException, status , Query
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.security import OAuth2PasswordBearer
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app import crud, models, schemas
from app.database import SessionLocal, engine
from services.omdb import fetch_omdb_data

# Configuration
SECRET_KEY = "09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4caa6cf63b88e8d3e7"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# App initialization
app = FastAPI()

# Setup static files
app.mount("/static", StaticFiles(directory="static"), name="static")
os.makedirs("static/css", exist_ok=True)
os.makedirs("static/js", exist_ok=True)

# Auth setup
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Templates setup
templates = Jinja2Templates(directory="templates")

# Database setup
models.Base.metadata.create_all(bind=engine)

env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env')
load_dotenv(dotenv_path=env_path)
# Add this right after your load_dotenv() call
print(f"Current environment keys: {os.environ.keys()}")
print(f"OMDB_API_KEY exists: {'OMDB_API_KEY' in os.environ}")

# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Helper function to create access token
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# Custom OAuth2 for cookie handling
class OAuth2PasswordBearerWithCookie(OAuth2PasswordBearer):
    async def __call__(self, request: Request) -> Optional[str]:
        # Check cookie first
        token = request.cookies.get("access_token")
        if token:
            return token
        return await super().__call__(request)

oauth2_scheme = OAuth2PasswordBearerWithCookie(tokenUrl="token")



import urllib.parse



async def fetch_omdb_data(title: str):
    api_key = os.getenv('OMDB_API_KEY')
    
    if not api_key:
        raise HTTPException(
            status_code=500, 
            detail="OMDb API key is missing. Please set OMDb_API_KEY in your environment variables."
        )
    
    # Properly encode the title using urllib.parse
    title_encoded = urllib.parse.quote_plus(title)
    
    # Use HTTPS instead of HTTP
    url = f"https://www.omdbapi.com/?apikey={api_key}&t={title_encoded}"

    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(url, timeout=10.0)
            
            # Check HTTP status first
            if response.status_code != 200:
                raise HTTPException(
                    status_code=response.status_code,
                    detail=f"OMDb API request failed with status {response.status_code}"
                )
                
            data = response.json()
            print("OMDb API Response:", data)  # Debug logging

            if data.get("Response") == "True":
                return {
                    "title": data.get("Title"),
                    "year": data.get("Year"),
                    "director": data.get("Director"),
                    "poster_url": data.get("Poster")
                }
            else:
                error_msg = data.get("Error", "Unknown error from OMDb")
                print(f"OMDb Error: {error_msg}")
                return None
    
    except httpx.RequestError as e:
        print(f"Request to OMDb failed: {str(e)}")
        raise HTTPException(
            status_code=503,
            detail=f"Could not connect to OMDb API: {str(e)}"
        )

# User authentication functions
async def get_current_user(
    request: Request,
    db: Session = Depends(get_db)
):
    token = request.cookies.get("access_token")
    if not token:
        return None
    
    try:
        if token.startswith("Bearer "):
            token = token[7:]
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            return None
    except JWTError:
        return None
    
    user = crud.get_user_by_email(db, email=email)
    return user

async def get_current_active_user(
    current_user: models.User = Depends(get_current_user)
):
    if current_user and not current_user.is_active:
        return None
    return current_user

# Root route - redirect to login
@app.get("/")
async def root():
    return RedirectResponse(url="/login")

# Auth routes
@app.get("/login")
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
async def login_user(
    request: Request,
    username: str = Form(...),  # This is actually the email
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    user = crud.get_user_by_email(db, email=username)
    if not user or not pwd_context.verify(password, user.hashed_password):
        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": "Incorrect email or password"
        })
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email},
        expires_delta=access_token_expires
    )
    
    response = RedirectResponse(url="/home", status_code=status.HTTP_302_FOUND)
    response.set_cookie(
        key="access_token",
        value=f"Bearer {access_token}",
        httponly=True,
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60
    )
    return response

@app.get("/register")
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.post("/register")
async def register(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    confirm_password: str = Form(...),
    username: str = Form(...),
    db: Session = Depends(get_db)
):
    # Check if the email is already taken
    db_user = crud.get_user_by_email(db, email=email)
    if db_user:
        return templates.TemplateResponse("register.html", {
            "request": request,
            "error": "Email already registered"
        })
    
    # Check if passwords match
    if password != confirm_password:
        return templates.TemplateResponse("register.html", {
            "request": request,
            "error": "Passwords do not match"
        })
    
    # Hash the password and create the user
    hashed_password = pwd_context.hash(password)
    db_user = models.User(
        email=email,
        username=username,
        hashed_password=hashed_password,
        is_active=True
    )
    db.add(db_user)
    db.commit()
    
    # Automatically log in after registration
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": email},
        expires_delta=access_token_expires
    )
    
    response = RedirectResponse(url="/home", status_code=status.HTTP_302_FOUND)
    response.set_cookie(
        key="access_token",
        value=f"Bearer {access_token}",
        httponly=True,
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60
    )
    return response

@app.get("/logout")
async def logout():
    response = RedirectResponse(url="/login")
    response.delete_cookie("access_token")
    return response

# Protected routes
@app.get("/home")
async def home(
    request: Request, 
    skip: int = 0, 
    limit: int = 10, 
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        return RedirectResponse(url="/login")
        
    # Fetch movies for the current user
    movies = crud.get_movies(db=db, owner_id=current_user.id, skip=skip, limit=limit)
    
    # Return the page with movie data and pagination info
    return templates.TemplateResponse("movies_list.html", {
        "request": request,
        "movies": movies,
        "skip": skip,
        "limit": limit,
        "current_user": current_user
    })


@app.post("/movies/")
async def create_movie(
    request: Request,
    title: str = Form(...),
    genre: str = Form(...),
    watched: bool = Form(False),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        return RedirectResponse(url="/login")

    omdb_data = await fetch_omdb_data(title)

    movie_data = {
        "title": title,
        "genre": genre,
        "watched": watched,
        "owner_id": current_user.id,
        "year": omdb_data.get("year") if omdb_data else None,
        "director": omdb_data.get("director") if omdb_data else None,
        "poster_url": omdb_data.get("poster_url") if omdb_data else None
    }

    db.add(models.Movie(**movie_data))
    db.commit()
    return RedirectResponse(url="/home", status_code=status.HTTP_303_SEE_OTHER)

@app.get("/movies/edit/{movie_id}", response_class=HTMLResponse)
async def edit_movie_form(
    request: Request,
    movie_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        return RedirectResponse(url="/login")
        
    movie = crud.get_movie_by_id(db, movie_id=movie_id, owner_id=current_user.id)
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found")
    
    return templates.TemplateResponse("edit_movie.html", {
        "request": request,
        "movie": movie
    })


@app.post("/movies/update/{movie_id}")
async def update_movie(
    request: Request,
    movie_id: int,
    title: str = Form(...),
    genre: str = Form(...),
    watched: bool = Form(False),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        return RedirectResponse(url="/login")
    
    movie_update = schemas.MovieBase(
        title=title,
        genre=genre,
        watched=watched
    )
    crud.update_movie(db, movie_id=movie_id, movie_update=movie_update, owner_id=current_user.id)
    return RedirectResponse(url="/home", status_code=status.HTTP_303_SEE_OTHER)

@app.get("/movies/delete/{movie_id}")
async def delete_movie_route(
    request: Request,
    movie_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        return RedirectResponse(url="/login")
    
    crud.delete_movie(db, movie_id=movie_id, owner_id=current_user.id)
    return RedirectResponse(url="/home", status_code=status.HTTP_303_SEE_OTHER)

# Search routes
@app.get("/search", response_class=HTMLResponse)
async def search_form(
    request: Request,
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        return RedirectResponse(url="/login")
    return templates.TemplateResponse("search.html", {"request": request})

@app.post("/search/results", response_class=HTMLResponse)
async def search_results(
    request: Request,
    title: Optional[str] = Form(None),
    genre: Optional[str] = Form(None),
    watched: Optional[str] = Form(None),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        return RedirectResponse(url="/login")
        
    watched_bool = None
    if watched == "true":
        watched_bool = True
    elif watched == "false":
        watched_bool = False
    
    movies = crud.search_movies(db, owner_id=current_user.id, title=title, genre=genre, watched=watched_bool)
    return templates.TemplateResponse("search_results.html", {
        "request": request,
        "movies": movies,
        "search_params": {
            "title": title,
            "genre": genre,
            "watched": watched
        }
    })


# API endpoints (protected)
@app.get("/api/movies/")
def read_movies(
    skip: int = 0,
    limit: int = 10,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    movies = crud.get_movies(db=db, skip=skip, limit=limit)
    return movies or []

@app.get("/api/movies/search")
def api_search_movies(
    title: str = Query(None),
    genre: str = Query(None),
    watched: bool = Query(None),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    movies = crud.search_movies(db, title=title, genre=genre, watched=watched)
    return {"results": movies}

# Sample data initialization
@app.get("/add_sample_movies")
async def add_sample_movies(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        return RedirectResponse(url="/login")
        
    # First, delete any existing sample movies for this user
    db.query(models.Movie)\
      .filter(models.Movie.owner_id == current_user.id)\
      .filter(models.Movie.title.in_([
          "The Shawshank Redemption",
          "Inception",
          "The Dark Knight"
      ]))\
      .delete(synchronize_session=False)
    
    # Add new sample movies
    sample_movies = [
        {"title": "The Shawshank Redemption", "genre": "Drama", "watched": True, "owner_id": current_user.id},
        {"title": "Inception", "genre": "Sci-Fi", "watched": False, "owner_id": current_user.id},
        {"title": "The Dark Knight", "genre": "Action", "watched": True, "owner_id": current_user.id},
    ]
    
    for movie in sample_movies:
        db.add(models.Movie(**movie))
    
    db.commit()
    return RedirectResponse(url="/home", status_code=status.HTTP_303_SEE_OTHER)

@app.get("/api/movies/{movie_id}/omdb")
async def fetch_movie_from_omdb(
    movie_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    movie = crud.get_movie_by_id(db, movie_id=movie_id, owner_id=current_user.id)
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found")
    
    omdb_data = await fetch_omdb_data(movie.title)
    
    if omdb_data:
        movie.year = omdb_data.get("year")
        movie.director = omdb_data.get("director")
        movie.poster_url = omdb_data.get("poster_url")
        db.commit()
        db.refresh(movie)
    
    return omdb_data

@app.put("/api/movies/{movie_id}/rate")
async def rate_movie(
    movie_id: int,
    movie_rating: schemas.MovieRating,  # Use schemas.MovieRating here
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    
    # Fetch the movie
    movie = crud.get_movie_by_id(db, movie_id=movie_id, owner_id=current_user.id)
    if not movie:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Movie not found")
    
    # Check if the rating is within the valid range
    if movie_rating.rating < 1 or movie_rating.rating > 5:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Rating must be between 1 and 5")
    
    # Update the movie rating
    movie.rating = movie_rating.rating
    db.commit()
    db.refresh(movie)
    
    return {
        "message": "Movie rated successfully", 
        "movie": {
            "id": movie.id,
            "title": movie.title,
            "rating": movie.rating,
            # Include other fields you might need
        }
    }

# Add movie to watchlist
@app.post("/api/movies/{movie_id}/watchlist")
async def add_to_watchlist(
    movie_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    
    movie = crud.get_movie_by_id(db, movie_id=movie_id, owner_id=current_user.id)
    if not movie:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Movie not found")
    
    movie.in_watchlist = True  # Assuming you have a `in_watchlist` field in your `Movie` model
    db.commit()
    db.refresh(movie)
    
    return {
        "message": "Movie added to watchlist", 
        "movie": {"id": movie.id, "title": movie.title, "in_watchlist": movie.in_watchlist}
    }

# Remove movie from watchlist
@app.delete("/api/movies/{movie_id}/watchlist")
async def remove_from_watchlist(
    movie_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    
    movie = crud.get_movie_by_id(db, movie_id=movie_id, owner_id=current_user.id)
    if not movie:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Movie not found")
    
    movie.in_watchlist = False
    db.commit()
    db.refresh(movie)
    
    return {
        "message": "Movie removed from watchlist", 
        "movie": {"id": movie.id, "title": movie.title, "in_watchlist": movie.in_watchlist}
    }

# Get all movies in the watchlist

@app.get("/watchlist")
async def watchlist(
    request: Request, 
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    if not current_user:
        return RedirectResponse(url="/login")
    
    try:
        # Fetch movies that are in the watchlist for the current user
        watchlist_movies = db.query(models.Movie).filter(
            models.Movie.owner_id == current_user.id, 
            models.Movie.in_watchlist == True
        ).all()

        print(f"Watchlist movies: {watchlist_movies}")  # Debug output

        return templates.TemplateResponse("watchlist.html", {
            "request": request,
            "watchlist_movies": watchlist_movies,
            "current_user": current_user,
            "message": "Your watchlist" if watchlist_movies else "Your watchlist is empty"
        })
    
    except Exception as e:
        print(f"Error fetching watchlist: {str(e)}")
        return templates.TemplateResponse("watchlist.html", {
            "request": request,
            "error_message": "Could not load watchlist",
            "current_user": current_user
        })


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)