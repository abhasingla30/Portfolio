from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, current_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from .models import User, Log
from .extensions import db
from .utils import log_action
import pyotp
import qrcode
from io import BytesIO
import base64

auth = Blueprint('auth', __name__)

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False
        
        user = User.query.filter_by(username=username).first()
        
        if not user or not user.check_password(password):
            flash('Invalid username or password')
            return redirect(url_for('auth.login'))
        
        if user.tfa_secret:
            return redirect(url_for('auth.tfa_verify', username=username, remember=remember))
        
        login_user(user, remember=remember)
        log_action(user.id, 'login', request.remote_addr)
        return redirect(url_for('main.index'))
    
    return render_template('auth/login.html')

@auth.route('/tfa/verify/<username>/<remember>', methods=['GET', 'POST'])
def tfa_verify(username, remember):
    user = User.query.filter_by(username=username).first()
    
    if not user:
        flash('Invalid user')
        return redirect(url_for('auth.login'))
    
    if request.method == 'POST':
        token = request.form.get('token')
        
        if user.verify_tfa(token):
            login_user(user, remember=(remember == 'True'))
            log_action(user.id, 'login', request.remote_addr)
            return redirect(url_for('main.index'))
        else:
            flash('Invalid token')
    
    return render_template('auth/tfa.html')

@auth.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return redirect(url_for('auth.register'))
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists')
            return redirect(url_for('auth.register'))
        
        user = User(username=username, email=email)
        user.set_password(password)
        
        # Generate TFA secret
        user.tfa_secret = pyotp.random_base32()
        
        db.session.add(user)
        db.session.commit()
        
        log_action(user.id, 'register', request.remote_addr)
        flash('Registration successful. Please log in.')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/register.html')

@auth.route('/logout')
@login_required
def logout():
    log_action(current_user.id, 'logout', request.remote_addr)
    logout_user()
    return redirect(url_for('main.index'))