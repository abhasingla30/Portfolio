from datetime import datetime
from .models import Log, db
from flask import current_app
import logging
from logging.handlers import RotatingFileHandler
import os

def setup_logging():
    if not os.path.exists(current_app.config['LOG_FOLDER']):
        os.makedirs(current_app.config['LOG_FOLDER'])
    
    file_handler = RotatingFileHandler(
        os.path.join(current_app.config['LOG_FOLDER'], 'app.log'),
        maxBytes=10240,
        backupCount=10
    )
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    current_app.logger.addHandler(file_handler)
    current_app.logger.setLevel(logging.INFO)
    current_app.logger.info('Application startup')

def log_action(user_id, action, ip_address, details=None):
    log = Log(
        user_id=user_id,
        action=action,
        ip_address=ip_address,
        details=details
    )
    db.session.add(log)
    db.session.commit()
    current_app.logger.info(f'User {user_id} performed {action} from {ip_address}')

def generate_expiration_date(days=7):
    from datetime import datetime, timedelta
    return datetime.utcnow() + timedelta(days=days)