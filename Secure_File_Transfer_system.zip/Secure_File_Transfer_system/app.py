import os
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash, current_app
from werkzeug.utils import secure_filename
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
import base64
import json
from config import Config
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
import pyotp
import qrcode
from io import BytesIO
import logging
from logging.handlers import RotatingFileHandler

# Initialize extensions
db = SQLAlchemy()
login_manager = LoginManager()
migrate = Migrate()

def setup_logging():
    file_handler = RotatingFileHandler(
        os.path.join(current_app.config['LOG_FOLDER'], 'app.log'),
        maxBytes=10240,
        backupCount=10
    )
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    current_app.logger.addHandler(file_handler)
    current_app.logger.setLevel(logging.INFO)
    current_app.logger.info('Application startup')

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions with app
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'login'
    migrate.init_app(app, db)

    # Setup logging
    with app.app_context():
        setup_logging()
        # Create all directories
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        os.makedirs(app.config['KEY_FOLDER'], exist_ok=True)
        os.makedirs(app.config['LOG_FOLDER'], exist_ok=True)
        # Create database tables
        db.create_all()

    return app

app = create_app()

# Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True, unique=True)
    email = db.Column(db.String(120), index=True, unique=True)
    password_hash = db.Column(db.String(128))
    tfa_secret = db.Column(db.String(16))
    last_login = db.Column(db.DateTime)
    files = db.relationship('File', backref='owner', lazy='dynamic')
    shared_files = db.relationship('FileShare', foreign_keys='FileShare.recipient_id', backref='recipient', lazy='dynamic')
    logs = db.relationship('Log', backref='user', lazy='dynamic')

    # ✅ THIS is what must exist inside the class
    def set_password(self, password):
        self.password_hash = generate_password_hash(password, method='pbkdf2:sha256')

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


    def get_tfa_uri(self):
        return pyotp.totp.TOTP(self.tfa_secret).provisioning_uri(
            name=self.username,
            issuer_name=current_app.config['TFA_ISSUER']
        )

    def verify_tfa(self, token):
        return pyotp.totp.TOTP(self.tfa_secret).verify(token)

class File(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(256))
    encrypted_filename = db.Column(db.String(256))
    metadata_filename = db.Column(db.String(256))
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    upload_date = db.Column(db.DateTime, index=True, default=datetime.utcnow)
    expiration_date = db.Column(db.DateTime)
    shares = db.relationship('FileShare', backref='file', lazy='dynamic')

class FileShare(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    file_id = db.Column(db.Integer, db.ForeignKey('file.id'))
    recipient_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    shared_date = db.Column(db.DateTime, default=datetime.utcnow)
    can_download = db.Column(db.Boolean, default=True)
    can_share = db.Column(db.Boolean, default=False)

class Log(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    action = db.Column(db.String(64))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    ip_address = db.Column(db.String(64))
    details = db.Column(db.Text)

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))

def log_action(user_id, action, ip_address, details=None):
    log = Log(
        user_id=user_id,
        action=action,
        ip_address=ip_address,
        details=details
    )
    db.session.add(log)
    db.session.commit()
    current_app.logger.info(f'User {user_id} performed {action} from {ip_address}')

def generate_rsa_keys():
    private_key_path = os.path.join(current_app.config['KEY_FOLDER'], 'private_key.pem')
    public_key_path = os.path.join(current_app.config['KEY_FOLDER'], 'public_key.pem')
    
    if os.path.exists(private_key_path) and os.path.exists(public_key_path):
        with open(private_key_path, 'rb') as f:
            private_key = RSA.import_key(f.read())
        with open(public_key_path, 'rb') as f:
            public_key = RSA.import_key(f.read())
    else:
        key = RSA.generate(2048)
        private_key = key
        public_key = key.publickey()
        
        with open(private_key_path, 'wb') as f:
            f.write(private_key.export_key())
        with open(public_key_path, 'wb') as f:
            f.write(public_key.export_key())
    
    return private_key, public_key

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']

def encrypt_file(file_path, public_key):
    aes_key = get_random_bytes(32)
    cipher_aes = AES.new(aes_key, AES.MODE_CBC)
    
    with open(file_path, 'rb') as f:
        file_data = f.read()
    
    ct_bytes = cipher_aes.encrypt(pad(file_data, AES.block_size))
    
    cipher_rsa = PKCS1_OAEP.new(public_key)
    enc_aes_key = cipher_rsa.encrypt(aes_key)
    
    metadata = {
        'iv': base64.b64encode(cipher_aes.iv).decode('utf-8'),
        'enc_aes_key': base64.b64encode(enc_aes_key).decode('utf-8')
    }
    
    encrypted_file_path = file_path + '.enc'
    with open(encrypted_file_path, 'wb') as f:
        f.write(ct_bytes)
    
    metadata_file_path = file_path + '.meta'
    with open(metadata_file_path, 'w') as f:
        json.dump(metadata, f)
    
    return encrypted_file_path, metadata_file_path

def decrypt_file(encrypted_file_path, metadata_file_path, private_key):
    with open(metadata_file_path, 'r') as f:
        metadata = json.load(f)
    
    cipher_rsa = PKCS1_OAEP.new(private_key)
    enc_aes_key = base64.b64decode(metadata['enc_aes_key'])
    aes_key = cipher_rsa.decrypt(enc_aes_key)
    
    iv = base64.b64decode(metadata['iv'])
    
    with open(encrypted_file_path, 'rb') as f:
        ct_bytes = f.read()
    
    cipher_aes = AES.new(aes_key, AES.MODE_CBC, iv)
    pt = unpad(cipher_aes.decrypt(ct_bytes), AES.block_size)
    
    decrypted_file_path = encrypted_file_path[:-4]
    with open(decrypted_file_path, 'wb') as f:
        f.write(pt)
    
    return decrypted_file_path

@app.route('/')
@login_required
def index():
    log_action(current_user.id, 'view_index', request.remote_addr)
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        
        file = request.files['file']
        
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            encrypted_file_path, metadata_file_path = encrypt_file(file_path, generate_rsa_keys()[1])
            os.remove(file_path)
            
            expiration_days = int(request.form.get('expiration_days', 7))
            expiration_date = datetime.utcnow() + timedelta(days=expiration_days)
            
            new_file = File(
                filename=filename,
                encrypted_filename=os.path.basename(encrypted_file_path),
                metadata_filename=os.path.basename(metadata_file_path),
                owner_id=current_user.id,
                expiration_date=expiration_date
            )
            db.session.add(new_file)
            db.session.commit()
            
            log_action(current_user.id, 'upload_file', request.remote_addr, f'File: {filename}')
            flash('File successfully uploaded and encrypted')
            return redirect(url_for('index'))
    
    return render_template('upload.html')

@app.route('/downloads')
@login_required
def list_files():
    owned_files = current_user.files.all()
    shared_files = FileShare.query.filter_by(recipient_id=current_user.id).all()
    
    files = []
    for file in owned_files:
        files.append({
            'id': file.id,
            'filename': file.filename,
            'is_owner': True,
            'expires': file.expiration_date.strftime('%Y-%m-%d') if file.expiration_date else 'Never'
        })
    
    for share in shared_files:
        if share.can_download:
            files.append({
                'id': share.file.id,
                'filename': share.file.filename,
                'is_owner': False,
                'shared_by': share.file.owner.username,
                'expires': share.file.expiration_date.strftime('%Y-%m-%d') if share.file.expiration_date else 'Never'
            })
    
    log_action(current_user.id, 'view_downloads', request.remote_addr)
    return render_template('download.html', files=files)

@app.route('/download/<int:file_id>')
@login_required
def download_file(file_id):
    file = File.query.get_or_404(file_id)
    
    if file.owner_id != current_user.id:
        share = FileShare.query.filter_by(file_id=file_id, recipient_id=current_user.id).first()
        if not share or not share.can_download:
            flash('You do not have permission to download this file')
            return redirect(url_for('list_files'))
    
    if file.expiration_date and file.expiration_date < datetime.utcnow():
        flash('This file has expired')
        return redirect(url_for('list_files'))
    
    encrypted_file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], file.encrypted_filename)
    metadata_file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], file.metadata_filename)
    
    decrypted_file_path = decrypt_file(encrypted_file_path, metadata_file_path, generate_rsa_keys()[0])
    
    log_action(current_user.id, 'download_file', request.remote_addr, f'File ID: {file_id}')
    response = send_from_directory(
        current_app.config['UPLOAD_FOLDER'],
        os.path.basename(decrypted_file_path),
        as_attachment=True
    )
    
    @response.call_on_close
    def remove_file():
        try:
            os.remove(decrypted_file_path)
        except:
            pass
    
    return response

@app.route('/share/<int:file_id>', methods=['GET', 'POST'])
@login_required
def share_file(file_id):
    file = File.query.get_or_404(file_id)
    
    if file.owner_id != current_user.id:
        flash('You can only share files you own')
        return redirect(url_for('list_files'))
    
    if request.method == 'POST':
        recipient_username = request.form['recipient']
        recipient = User.query.filter_by(username=recipient_username).first()
        
        if not recipient:
            flash('User not found')
            return redirect(url_for('share_file', file_id=file_id))
        
        if recipient.id == current_user.id:
            flash('You cannot share a file with yourself')
            return redirect(url_for('share_file', file_id=file_id))
        
        existing_share = FileShare.query.filter_by(file_id=file_id, recipient_id=recipient.id).first()
        if existing_share:
            flash('This file is already shared with this user')
            return redirect(url_for('share_file', file_id=file_id))
        
        new_share = FileShare(
            file_id=file_id,
            recipient_id=recipient.id,
            can_download='can_download' in request.form,
            can_share='can_share' in request.form
        )
        db.session.add(new_share)
        db.session.commit()
        
        log_action(current_user.id, 'share_file', request.remote_addr, 
                  f'File ID: {file_id} with user {recipient.username}')
        flash('File shared successfully')
        return redirect(url_for('list_files'))
    
    return render_template('share.html', file=file)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        remember = True if 'remember' in request.form else False
        
        user = User.query.filter_by(username=username).first()
        
        if not user or not user.check_password(password):
            flash('Invalid username or password')
            return redirect(url_for('login'))
        
        if user.tfa_secret:
            return redirect(url_for('tfa_verify', username=username, remember=remember))
        
        login_user(user, remember=remember)
        log_action(user.id, 'login', request.remote_addr)
        return redirect(url_for('index'))
    
    return render_template('auth/login.html')

@app.route('/tfa/verify/<username>/<remember>', methods=['GET', 'POST'])
def tfa_verify(username, remember):
    user = User.query.filter_by(username=username).first()
    
    if not user:
        flash('Invalid user')
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        token = request.form['token']
        
        if user.verify_tfa(token):
            login_user(user, remember=(remember == 'True'))
            log_action(user.id, 'login', request.remote_addr)
            return redirect(url_for('index'))
        else:
            flash('Invalid token')
    
    return render_template('auth/tfa.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    qr_code_data = None

    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return redirect(url_for('register'))

        if User.query.filter_by(email=email).first():
            flash('Email already exists')
            return redirect(url_for('register'))

        user = User(username=username, email=email)
        user.set_password(password)
        user.tfa_secret = pyotp.random_base32()

        db.session.add(user)
        db.session.commit()

        log_action(user.id, 'register', request.remote_addr)
        flash('Registration successful. Scan the QR code with your Authenticator app and then log in.')

        # ✅ Generate QR code from TFA URI
        tfa_uri = user.get_tfa_uri()
        img = qrcode.make(tfa_uri)
        buffer = BytesIO()
        img.save(buffer, format='PNG')
        qr_code_data = base64.b64encode(buffer.getvalue()).decode('utf-8')

        # Show QR code to scan
        return render_template('auth/register.html', qr_code_data=qr_code_data)

    return render_template('auth/register.html')


@app.route('/logout', methods=['POST'])
@login_required
def logout():
    log_action(current_user.id, 'logout', request.remote_addr)
    logout_user()
    return redirect(url_for('index'))


@app.route('/my_files')
@login_required
def my_files():
    files = File.query.filter_by(owner_id=current_user.id).all()
    return render_template('my_files.html', files=files)

if __name__ == '__main__':
    app.run(debug=True)

   