from datetime import datetime, timedelta
from app import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
import pyotp

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True, unique=True)
    email = db.Column(db.String(120), index=True, unique=True)
    password_hash = db.Column(db.String(128))
    tfa_secret = db.Column(db.String(16))
    last_login = db.Column(db.DateTime)
    files = db.relationship('File', backref='owner', lazy='dynamic')
    shared_files = db.relationship('FileShare', foreign_keys='FileShare.recipient_id', backref='recipient', lazy='dynamic')
    logs = db.relationship('Log', backref='user', lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def get_tfa_uri(self):
        return pyotp.totp.TOTP(self.tfa_secret).provisioning_uri(
            name=self.username,
            issuer_name=current_app.config['TFA_ISSUER']
        )

    def verify_tfa(self, token):
        return pyotp.totp.TOTP(self.tfa_secret).verify(token)

class File(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(256))
    encrypted_filename = db.Column(db.String(256))
    metadata_filename = db.Column(db.String(256))
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    upload_date = db.Column(db.DateTime, index=True, default=datetime.utcnow)
    expiration_date = db.Column(db.DateTime)
    shares = db.relationship('FileShare', backref='file', lazy='dynamic')

class FileShare(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    file_id = db.Column(db.Integer, db.ForeignKey('file.id'))
    recipient_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    shared_date = db.Column(db.DateTime, default=datetime.utcnow)
    can_download = db.Column(db.Boolean, default=True)
    can_share = db.Column(db.Boolean, default=False)

class Log(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    action = db.Column(db.String(64))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    ip_address = db.Column(db.String(64))
    details = db.Column(db.Text)

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))