"""
Movie Recommendation System

This application provides an interactive interface to help users discover movies based on their mood, search preferences, and dynamic filters. 
It utilizes Panel for a web-based GUI and pandas for data manipulation. Users can:

- Select a mood to get genre-based recommendations.
- Search for specific movies by name.
- Apply filters such as genre, platform, language, rating, and votes.
- Sort results by rating or year.
- Navigate results with pagination.

The app is designed to be user-friendly and responsive, offering a seamless movie exploration experience.

- Command for running the application - panel serve app.py --autoreload
- Copy the http://localhost:5006/app and run on browser
"""
# Import required libraries
import pandas as pd
import panel as pn

# Initialize Panel extension
pn.extension()

# Load dataset 
try:
    data = pd.read_csv("inva.csv")
    data.rename(columns=lambda x: x.strip(), inplace=True)
    print("Dataset loaded successfully!")
except Exception as e:
    print(f"Error loading dataset: {e}")
    data = pd.DataFrame()

# Ensure data is clean
def clean_data():
    global data
    if not data.empty:
        # Standardize columns
        data["Genre"] = data["Genre"].str.strip().str.title()
        data["Platform"] = data["Platform"].str.strip().str.title()
        data["Language"] = data["Language"].str.strip().str.title()
        data["Rating(10)"] = pd.to_numeric(data["Rating(10)"], errors="coerce")
        data["Votes"] = pd.to_numeric(data["Votes"], errors="coerce")  # Ensure Votes column is numeric

clean_data()

# Pagination setup
rows_per_page = 20
current_page = 0

# Mood mapping
mood_genres = {
    "Happy": ["Comedy", "Animation", "Family", "Musical"],
    "Sad": ["Drama", "Biography", "Romance"],
    "Adventurous": ["Action", "Adventure", "Fantasy", "Sci-Fi"],
    "Thrilled": ["Thriller", "Crime", "Mystery", "Horror"],
    "Relaxed": ["Documentary", "Music", "Short", "Reality-TV", "Talk-Show"],
}

movie_table = pn.pane.HTML("", width=700, height=500)

# Page 1 Widgets (Mood Selection and Search)
mood_select = pn.widgets.Select(name="", options=[""] + list(mood_genres.keys()), width=400, height=60)
search_input = pn.widgets.TextInput(name="", placeholder="Type a movie name", width=400, height=60)
search_button = pn.widgets.Button(name="Search", button_type="primary", width=400, height=60)

# Page 2 Widgets (Results and Filters)
sort_select = pn.widgets.Select(
    name="Sort By",
    options=["", "Rating (High to Low)", "Rating (Low to High)", "Year (Newest First)", "Year (Oldest First)"],
    width=400, height=60
)
genre_filter = pn.widgets.MultiChoice(name="Filter by Genre", options=[], width=400, height=100)
platform_filter = pn.widgets.MultiChoice(name="Filter by Platform", options=[], width=400, height=100)
language_filter = pn.widgets.MultiChoice(name="Filter by Language", options=[], width=400, height=100)
rating_filter = pn.widgets.RangeSlider(name="Rating Filter", start=0, end=10, value=(0, 10), step=0.1, width=400, height=60)
votes_filter = pn.widgets.IntRangeSlider(name="Filter by Votes", start=0, end=2500, value=(0, 2500), width=400, height=60)

movie_table = pn.pane.HTML("", width=700, height=500)

# Back and Next buttons for pagination
next_button = pn.widgets.Button(name="Next", button_type="primary", width=400, height=60)
prev_button = pn.widgets.Button(name="Previous", button_type="primary", width=400, height=60)

# Back button
back_button = pn.widgets.Button(name="Back to Search", button_type="primary", width=400, height=60)
clear_filters_button = pn.widgets.Button(name="Clear Filters", button_type="danger", width=100, height=30)

#clear filter button
def clear_filters(event=None):
    global current_page
    current_page = 0  # Reset to first page
    genre_filter.value = []
    platform_filter.value = []
    language_filter.value = []
    rating_filter.value = (0, 10)
    votes_filter.value = (0, 2500)
    sort_select.value = ""
    update_table()

# Attach clear filter button click event
clear_filters_button.on_click(clear_filters)


# Update function for the first page
def update_table(event=None):
    global current_page
    mood = mood_select.value
    search = search_input.value.strip()

    filtered_data = data.copy()

    # Filter by mood
    if mood:
        genres = mood_genres.get(mood, [])
        filtered_data = filtered_data[filtered_data["Genre"].isin(genres)]

    # Filter by search term
    if search:
        filtered_data = filtered_data[
            filtered_data["Movie Name"].str.contains(search, case=False, na=False)
        ]

    # Update dynamic filter options
    genre_filter.options = sorted(filtered_data["Genre"].unique().tolist())
    platform_filter.options = sorted(filtered_data["Platform"].unique().tolist())
    language_filter.options = sorted(filtered_data["Language"].unique().tolist())

    # Select only required columns (Movie Name, Language, Genre, Rating(10), Platform)
    filtered_data = filtered_data[["Movie Name", "Language", "Genre", "Rating(10)", "Platform"]]

    # Reset index to remove it
    filtered_data = filtered_data.reset_index(drop=True)

    # Calculate the start and end indices for pagination
    start_idx = current_page * rows_per_page
    end_idx = start_idx + rows_per_page

    # Slice the data to display only 20 rows
    page_data = filtered_data[start_idx:end_idx]

    # Convert DataFrame to HTML without index, adding style for font size and table width
    table_html = page_data.to_html(index=False, escape=False)
    
    # Add custom styles to adjust the font size and table width
    table_html = f"""
    <style>
        table {{
            font-size: 12px;  /* Adjust the font size */
            width: 700px;  /* Set the table width to a fixed value */
            table-layout: fixed;  /* Ensures table columns stay fixed */
        }}
        th, td {{
            padding: 5px;
            text-align: left;
        }}
        .container {{
            overflow-x: auto;  /* Enable horizontal scrolling if the table overflows */
            margin-top: 10px;
        }}
    </style>
    <div class="container">
        {table_html}
    </div>
    """

    # Update the table using HTML
    movie_table.object = table_html if not page_data.empty else "<p>No results found</p>"

# Next page function
def next_page(event=None):
    global current_page
    current_page += 1
    update_table()

# Previous page function
def prev_page(event=None):
    global current_page
    if current_page > 0:
        current_page -= 1
        update_table()

# Update function for the second page with pagination
def apply_filters(event=None):
    global current_page
    genres = genre_filter.value
    platforms = platform_filter.value
    languages = language_filter.value
    sort_by = sort_select.value
    rating_range = rating_filter.value
    votes_range = votes_filter.value  # Get the votes filter range

    filtered_data = data.copy()

    # Apply filters
    if genres:
        filtered_data = filtered_data[filtered_data["Genre"].isin(genres)]
    if platforms:
        filtered_data = filtered_data[filtered_data["Platform"].isin(platforms)]
    if languages:
        filtered_data = filtered_data[filtered_data["Language"].isin(languages)]

    # Apply rating filter
    filtered_data = filtered_data[
        (filtered_data["Rating(10)"] >= rating_range[0]) & (filtered_data["Rating(10)"] <= rating_range[1])
    ]

    # Apply votes filter
    filtered_data = filtered_data[
        (filtered_data["Votes"] >= votes_range[0]) & (filtered_data["Votes"] <= votes_range[1])
    ]

    # Apply sorting
    if sort_by == "Rating (High to Low)":
        filtered_data = filtered_data.sort_values(by="Rating(10)", ascending=False)
    elif sort_by == "Rating (Low to High)":
        filtered_data = filtered_data.sort_values(by="Rating(10)", ascending=True)
    elif sort_by == "Year (Newest First)":
        filtered_data = filtered_data.sort_values(by="Year", ascending=False)
    elif sort_by == "Year (Oldest First)":
        filtered_data = filtered_data.sort_values(by="Year", ascending=True)

    # Select only required columns (Movie Name, Language, Genre, Rating(10), Platform)
    filtered_data = filtered_data[["Movie Name", "Language", "Genre", "Rating(10)", "Platform"]]

    # Reset index to remove it
    filtered_data = filtered_data.reset_index(drop=True)

    # Pagination logic
    start_idx = current_page * rows_per_page
    end_idx = start_idx + rows_per_page
    page_data = filtered_data[start_idx:end_idx]

    # Convert DataFrame to HTML without index
    table_html = page_data.to_html(index=False, escape=False)

    table_html = f"""
    <style>
        table {{
            font-size: 12px;  /* Adjust the font size */
            width: 700px;  /* Set the table width to a fixed value */
            table-layout: fixed;  /* Ensures table columns stay fixed */
        }}
        th, td {{
            padding: 5px;
            text-align: left;
        }}
        .container {{
            overflow-x: auto;  /* Enable horizontal scrolling if the table overflows */
            margin-top: 10px;
        }}
    </style>
    <div class="container">
        {table_html}
    </div>
    """

    # Update the table using HTML
    movie_table.object = table_html if not page_data.empty else "<p>No results found</p>"

    # Update the filter options
    genre_filter.options = sorted(filtered_data["Genre"].unique().tolist())
    platform_filter.options = sorted(filtered_data["Platform"].unique().tolist())
    language_filter.options = sorted(filtered_data["Language"].unique().tolist())

# Navigation to results page
def show_results_page(event=None):
    update_table()
    page_layout[0] = results_page

# Back to search page
def back_to_search(event=None):
    page_layout[0] = first_page

# Attach event handlers
search_button.on_click(show_results_page)
back_button.on_click(back_to_search)
rating_filter.param.watch(apply_filters, 'value')
votes_filter.param.watch(apply_filters, 'value')
genre_filter.param.watch(apply_filters, 'value')
platform_filter.param.watch(apply_filters, 'value')
language_filter.param.watch(apply_filters, 'value')
sort_select.param.watch(apply_filters, 'value')
next_button.on_click(next_page)
prev_button.on_click(prev_page)


# Page 1 Layout 
first_page = pn.Column(
    pn.Row(
        pn.pane.HTML("<h1 style='font-size: 40px; color: #0073e6; text-align: center;'>Movie Recommendation System</h1>"),
        sizing_mode="stretch_width",  # Ensures the row stretches across the entire width
        align="center",  # Centers the content horizontally in the row
        margin=(0, 20, 50, 400)  # Adjusts the top margin to create some space from the very top
    ),

    pn.Row(
        pn.pane.HTML("<h1 style='font-size: 30px; color: black; text-align: center;'>Select Your Mood or Search for a Movie</h1>"),
        sizing_mode="stretch_width",  # Ensures the row stretches across the entire width
        align="center",  # Centers the content horizontally in the row
        margin=(0, 0, 0, 400)  # Adjusts the top margin to create some space from the very top
    ),
    pn.Row(
        pn.pane.HTML("<h3 style='font-size: 20px; color: black; text-align: center;'>Select a Mood</h3>"),  # Updated here
        sizing_mode="stretch_width",  # Ensures the row stretches across the entire width
        align="center",  # Centers the content horizontally in the row
        margin=(30, 30, 0, 620)  # Adjusts the top margin to create some space from the very top
    ),
    
    pn.Row(
        mood_select,  # Mood selection dropdown widget
        sizing_mode="stretch_width",  # Ensures the widget stretches horizontally
        align="center",  # Centers the widget horizontally
        margin=(0, 0, 0, 500)  # Adjusts margins to center vertically and horizontally
    ),
    
    pn.Row(
        pn.pane.HTML("<h3 style='font-size: 20px; color: black; text-align: center;'>Search for a Movie</h3>"),
        sizing_mode="stretch_width",
        align="center",
        margin=(0, 0, 0, 600)
    ),
    pn.Row(
        search_input,
        sizing_mode="stretch_width",
        align="center",  # Center the input widget
        margin=(0, 20, 20, 500)
    ),
    pn.Row(
        search_button,
        sizing_mode="stretch_width",
        align="center",  # Center the button widget
        margin=(0, 20, 20, 500)
    )
)

# Page 2 Layout
results_page = pn.Row(
    pn.Column(
        
        pn.Row(
        pn.pane.HTML("<h2 style='font-size: 30px; color: #0073e6; text-align: center;'>Movie Results</h2>"),
        sizing_mode="stretch_width",
        align="center",
        margin=(0, 0, 0, 500)
    ),
        pn.Row(
            sort_select,
            genre_filter,
             votes_filter,
            sizing_mode="stretch_width",  # Ensures filters take available width
            margin=(0, 0, 20, 0),
        ),
        pn.Row(
            platform_filter,
            language_filter,
             # Place the votes filter above the rating filter
            rating_filter,
            clear_filters_button,
             # Place rating filter below votes filter
            sizing_mode="stretch_width"  # Ensures filters take available width
        ),
        
        # Center the movie table
        pn.Row(
            movie_table,
            sizing_mode="stretch_width",  # Ensures it takes available width
            align="center",  # Centers the movie table horizontally
            margin=(0, 0, 0, 250)  # Adjusts margins to create space around it
        ),
        
        pn.Row(  # Pagination buttons at the bottom of the table
            back_button,
            prev_button,
            next_button,
            sizing_mode="stretch_width",
            align="center",
            margin=(250, 0, 0, 50),  # Adjust margins
        ),
        sizing_mode="stretch_width",
    ),
    pn.Column(width=150, sizing_mode="fixed", margin=(20, 0, 0, 0))
)


# Page layout toggler
page_layout = pn.Column(first_page)

# Serve the app
page_layout.servable()